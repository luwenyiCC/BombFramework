using System;
namespace Mono.CompilerServices.SymbolWriter
{
	public interface ICompileUnit
	{
		CompileUnitEntry Entry
		{
			get;
		}
	}
}
